module.exports = {
    BASE_URL: "https://dev.iqrakitab.net/api/",
};